/* Mr.Ho & Geoffrey Lee
 * Mr.Diakoloukas
 * ICS4UE
 * July 14, 2021
 * Program Name: TicTacEvent.java
 * Program Description: This program runs the GUI for Tic Tac Toe
*/

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;



public class TicTacEvent implements ItemListener, ActionListener, Runnable {
    TicTac gui;
    Thread playing;
    ImageIcon a = new ImageIcon("x.jpg");
    ImageIcon b = new ImageIcon("o.jpg");
    int clicks = 0;
    int win = 0;
    int winX = 0; //Intialize number of X wins to 0
    int winO = 0; //Intialize number of O wins to 0
    int tie = 0; //Intialize number of ties to 0
    int[][] check = new int[3][3];

    public TicTacEvent (TicTac in){
        gui = in;
        for (int row=0; row<=2; row++){
           for (int col=0; col<=2; col++){
               check[row][col]=0;
           }
       }
    }

    public void actionPerformed (ActionEvent event) {
       String command = event.getActionCommand();

       if (command.equals("Play")) {
           startPlaying();
       }
       if (command.equals("Exit")) { //Checks if user clicks exit
           exit(); //Performs exit function
       }
       if (command.equals("Reset")) { //Check if user clicks Reset
           reset(); //Performs reset function
       }
       if (command.equals("1")) {
           b1();
       }
       if (command.equals("2")) {
           b2();
       }
       if (command.equals("3")) {
           b3();
       }
       if (command.equals("4")) {
           b4();
       }
       if (command.equals("5")) {
           b5();
       }
       if (command.equals("6")) {
           b6();
       }
       if (command.equals("7")) {
           b7();
       }
       if (command.equals("8")) {
           b8();
       }
       if (command.equals("9")) {
           b9();
       }
    }

    void b1() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[0][0].setIcon(a);
            check[0][0] = 1;
        } else {
            gui.boxes[0][0].setIcon(b);
            check[0][0] = 2;
        }
        winner();

    }
    void b2() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[0][1].setIcon(a);
            check[0][1] = 1;
        } else {
            gui.boxes[0][1].setIcon(b);
            check[0][1] = 2;
        }
        winner();
    }
    void b3() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[0][2].setIcon(a);
            check[0][2] = 1;
        } else {
            gui.boxes[0][2].setIcon(b);
            check[0][2] = 2;
        }
        winner();
    }
    void b4() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[1][0].setIcon(a);
            check[1][0] = 1;
        } else {
            gui.boxes[1][0].setIcon(b);
            check[1][0] = 2;
        }
        winner();
    }
    void b5() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[1][1].setIcon(a);
            check[1][1] = 1;
        } else {
            gui.boxes[1][1].setIcon(b);
            check[1][1] = 2;
        }
        winner();
    }
    void b6() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[1][2].setIcon(a);
            check[1][2] = 1;
        } else {
            gui.boxes[1][2].setIcon(b);
            check[1][2] = 2;
        }
        winner();
    }
    void b7() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[2][0].setIcon(a);
            check[2][0] = 1;
        } else {
            gui.boxes[2][0].setIcon(b);
            check[2][0] = 2;
        }
        winner();
    }
    void b8() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[2][1].setIcon(a);
            check[2][1] = 1;
        } else {
            gui.boxes[2][1].setIcon(b);
            check[2][1] = 2;
        }
        winner();
    }
    void b9() {
        clicks = clicks + 1;
        if ((clicks%2)==1){
            gui.boxes[2][2].setIcon(a);
            check[2][2] = 1;
        } else {
            gui.boxes[2][2].setIcon(b);
            check[2][2] = 2;
        }
        winner();
    }
    void reset() { //This function resets the game to the beggining
        //loop through the coloms of the tic tac toe
        for (int i = 0; i < 3; i++) {
            //loop through the rows of teh tic tac toe
            for (int j = 0; j < 3; j++) {
                //Reset all the images back to the cardback icon
                gui.boxes[i][j].setIcon(gui.back);
            }  
        }
        //Reset the clicks counter back to 0
        clicks = 0;
        //loop through the coloms of the tic tac toe
        for (int i = 0; i < 3; i++) {
            //loop through the rows of teh tic tac toe
            for (int j = 0; j < 3; j++) {
                //reset each element in the two dimensional array back to 0 
                check[i][j] = 0;
            }
        }
        //Reset the win varaible back to 0
        win = 0;
        
    }
    void exit() { //This function exists the game
        System.exit(0); //Exits GUI
    }

    void winner() {
        /** Check rows for winner */
        
        for (int x=0; x<=2; x++){
            if ((check[x][0]==check[x][1])&&(check[x][0]==check[x][2])) {
                if (check[x][0]==1) {
                    JOptionPane.showMessageDialog(null, "X is the winner");
                    winX++; //Increment x wins by 1
                    win = 1;
                } else if (check[x][0]==2){
                    JOptionPane.showMessageDialog(null, "Y is the winner");
                    winO++; //Increment O wins by 1
                    win = 1;
                }
            }
        }

        /** Check columns for winner */
        for (int x=0; x<=2; x++){
            if ((check[0][x]==check[1][x])&&(check[0][x]==check[2][x])) {
                if (check[0][x]==1) {
                    JOptionPane.showMessageDialog(null, "X is the winner");
                    winX++; //Increment x wins by 1
                    win = 1;
                } else if (check[0][x]==2) {
                    JOptionPane.showMessageDialog(null, "Y is the winner");
                    winO++; //Increment O wins by 1
                    win = 1;
                }
            }
        }

        /** Check diagonals for winner */
        if (((check[0][0]==check[1][1])&&(check[0][0]==check[2][2]))||
                ((check[2][0]==check[1][1])&&(check[1][1]==check[0][2]))){
            if (check[1][1]==1) {
                JOptionPane.showMessageDialog(null, "X is the winner");
                winX++; //Increment x wins by 1
                win = 1;
            } else if (check[1][1]==2) {
                JOptionPane.showMessageDialog(null, "Y is the winner");
                winO++; //Increment O wins by 1
                win = 1;
            }

        }

        /** Checks if the game is a tie */
        if ((clicks==9) && (win==0)) {
            JOptionPane.showMessageDialog(null, "The game is a tie");
            tie++; //Increment number of ties by 1
        }
        //Output the number of x wins and y wins that have occured
        gui.txtXYwin.setText("# of X wins: " + winX + "\n" + "# of Y wins: " + winO);
        //Output the number of ties that have occured
        gui.txtTIEwin.setText("# of Ties: " + tie);
        
    }

     
    void startPlaying() {
        playing = new Thread(this);
        playing.start();
        gui.play.setEnabled(false);
    }

    public void itemStateChanged(ItemEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void run() {
        throw new UnsupportedOperationException("Not supported yet.");
    }


}

